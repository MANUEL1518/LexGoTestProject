import { Component, Injectable, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { FormsModule } from '@angular/forms'; 
import axios from 'axios';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, FormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})

@Injectable()
export class AppComponent{
  title = 'lexgoApp';
  company = {
    company_name: "",
    _id: "",
    company_id: 0
  }
  departaments = []
  ejectives = []
  employees = []

  // ********** Form variables

  username_input : any       = ""
  to_update : any            = false // Switch
  role_input : any           = ""
  company_selected : any     = ""
  departament_selected : any = ""
  ejecutive_selected : any   = ""
  employee_to_delete : any   = ""
  employee_selected : any    = {}

  ejectives_selectTag = []

  loading = false

  // **********

  clearForms() {
    // Se refrescan las variables de entorno
    this.username_input = ""
    this.to_update = false // Switch
    this.role_input = ""
    this.company_selected = ""
    this.departament_selected = ""
    this.ejecutive_selected = ""
    this.employee_to_delete = ""
    
    this.employee_selected = {}
  }

  fetchAll() {
    axios.get('http://localhost:3000/business_structure').then(response => {
        type EjecutiveType = {
          _id: string,
          employees: object,
          departament: string,
          company: string
        };
        type EmployeeType = {
          _id: string,
          ejective: string
        };
        type DepartamentType = {
          _id: string,
          ejectives: object
        };

        this.company = response.data.company;
        this.ejectives = response.data.ejectives.map((ejective : EjecutiveType) => {
          ejective.employees = response.data.employees.filter((_employee : EmployeeType) => ejective._id == _employee.ejective);
          return ejective;
        });
        this.employees = response.data.employees;
        
        this.departaments = response.data.departaments.map((departament : DepartamentType) => {
          departament.ejectives = response.data.ejectives.filter((eje : EjecutiveType) => eje.departament == departament._id).map((ejective : EjecutiveType) => {
            ejective.employees = response.data.employees.filter((_employee : EmployeeType) => ejective._id == _employee.ejective);
            return ejective;
          });

          return departament;
        });
    }).catch(e => {
      throw e;
    });  
  }

  selectOptions(departament : string = "") {
    let old_departament = (this.departament_selected !== '' && departament == "")? this.departament_selected : departament;
    let old_ejective = (this.ejecutive_selected !== '')? this.ejecutive_selected : this.employee_selected._id;

    if(departament !== "") {
      old_ejective = "";
    }

    this.employee_selected = {};
    this.clearForms();

    // Si no posee departamento heredado
    if(old_departament !== "") {
      this.ejectives_selectTag = this.ejectives.filter(ejective => ejective["departament"] == old_departament);
    } else {
      this.ejectives_selectTag = this.ejectives;
    }

    this.departament_selected = old_departament;
    this.ejecutive_selected   = old_ejective;
  }

  selectEmployee(employee : any) {
    console.log(employee._id);

    this.employee_selected = employee;
    // Ejectives Selector
    this.ejectives_selectTag = this.ejectives.filter(_employee => _employee["departament"] == this.employee_selected.departament && _employee["_id"] !== employee._id);

    // Set the Employee data
    this.username_input = employee.username;
    this.role_input = employee.role;
    this.departament_selected = employee.departament;

    // Validar si va a actualizar o crear uno nuevo
    this.ejecutive_selected = (employee.ejective !== null)? employee.ejective : ""; // employee._id
  }

  // Update Departament Selector
  updateDepartamentSelector() {
    this.ejectives_selectTag = this.ejectives.filter(_ejective => _ejective["departament"] == this.departament_selected && _ejective["_id"] !== this.employee_selected._id)
  }

  // CRUD UTILS
  updateEmployee() {
    let data_to_send = {
      username:    this.username_input,
      departament: this.departament_selected,
      role:        this.role_input,
      ejective:    null
    };

    if(this.ejecutive_selected != null || this.ejecutive_selected != "") {
      data_to_send.ejective = this.ejecutive_selected;
    }
    
    // Update
    axios.put("http://127.0.0.1:3000/employee/" + this.employee_selected._id, data_to_send).then(response => {
      this.employee_selected.username = data_to_send.username;
      this.employee_selected.role     = data_to_send.role;
      
      // Reload data
      this.fetchAll();
    });
    console.log("# Update Employee");
  }

  deleteEmployee() {
    axios.delete("http://127.0.0.1:3000/employee/" + this.employee_selected._id).then(response => {
      console.log(response);

      // Reload data
      this.fetchAll();
    });

    console.log("# Employee Deleted");
  }

  moveEmployee() {
    /**
     * En este apartado se valida si posee empleados.
     *  -> de poseer empleados estos se pasan directamente al mismo departamento
     *     pero sin ejecutivo.
     */
    axios.put("http://127.0.0.1:3000/employee/" + this.employee_selected._id, {
      departament: this.departament_selected,
      ejective:    this.ejecutive_selected
    }).then(response => {
      console.log(response.data);

      // Reload data
      this.fetchAll();
    });
  }

  createEmployee() {
    if(this.employee_selected._id) { // Validate update
      this.updateEmployee();
    } else { // Create Employee
      axios.post("http://127.0.0.1:3000/employee", {
          username:    this.username_input,
          role:        this.role_input,
          company:     this.company,
          departament: this.departament_selected,
          ejecutive:   this.ejecutive_selected
      }, {
        headers: {
          'Content-Type': 'application/json'
        }
      }).then(response => {
        console.log(response.data);
  
        // Reload data
        this.fetchAll();
      });
    }
  }

  ngOnInit() {
    this.fetchAll();
  }
}

