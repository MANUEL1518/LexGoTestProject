
const mongoose = require("mongoose");
var seeder = require('mongoose-seed');

const Company = require("../models/company");
const Departament = require("../models/departament");
const Employee = require("../models/employee");

mongoose.connect('mongodb://127.0.0.1:27017/')
    .catch(err => {
        console.log(err.stack);
        process.exit(1);
    })
    .then(async () => {
        // Execute Seed
        seeder.loadModels([
            '../models/employee.js',
            '../models/company.js',
            '../models/departament.js'
        ]);

        // Clear specified collections
        // seeder.clearModels(['Company', 'Departament', 'Employee'], function() {
        //     // Callback to populate DB once collections have been cleared
        //     // seeder.populateModels(data);
        // });

        var collections = mongoose.connections[0].collections;
        var names = [];
        
        Object.keys(collections).forEach(function(k) {
            // Clear companies
            mongoose.connection.collections[k].drop(function(err) {});
            names.push(k);
        });
        
        // Create LexGo Company / Departament
        let lexGo = new Company({
            company_name: "LexGo"
        });
        lexGo.company_id = lexGo._id;
        lexGo.save();

        setTimeout(function() {
            // Create LexGo Company / Departament
            // Departamento A
            let lexGoCompaniesA = new Departament({
                departament_name: "Departamento A", 
                company: lexGo._id
            });
            lexGoCompaniesA.departament_id = lexGoCompaniesA._id;
            lexGoCompaniesA.save();
    
            // Employee Regists
            let employee_a = new Employee({
                username:    "Alejandro González",
                role:        "Líder Dep. A",
                company:     lexGo._id,
                departament: lexGoCompaniesA._id,
                ejective:    null
            });
            employee_a.save();
            // SubEmployees
            new Employee({
                username:    "Javier López",
                role:        "Empleado Dep. A",
                company:     lexGo._id,
                departament: lexGoCompaniesA._id,
                ejective:    employee_a._id
            }).save();
            new Employee({
                username:    "Laura Fernández",
                role:        "Empleado Dep. A",
                company:     lexGo._id,
                departament: lexGoCompaniesA._id,
                ejective:    employee_a._id
            }).save();
            // Departamento A <--
    
            // Departamento B
            let lexGoCompaniesB = new Departament({
                departament_name: "Departamento B", 
                company: lexGo._id
            });
            lexGoCompaniesB.departament_id = lexGoCompaniesB._id;
            lexGoCompaniesB.save();
    
            // Employee Regists
            new Employee({
                username:    "Carlos Pérez",
                role:        "Empleado Dep. B",
                company:     lexGo._id,
                departament: lexGoCompaniesB._id,
                ejective:    null
            }).save();
            new Employee({
                username:    "Ana Martínez",
                role:        "Empleado Dep. B",
                company:     lexGo._id,
                departament: lexGoCompaniesB._id,
                ejective:    null
            }).save();
            // Departamento B <--
    
            // Departamento C
            let lexGoCompaniesC = new Departament({
                departament_name: "Departamento C", 
                company: lexGo._id
            });
    
            lexGoCompaniesC.departament_id = lexGoCompaniesC._id;
            lexGoCompaniesC.save();
    
            // Employee Regists
            let employee_c = new Employee({
                username:    "María Rodríguez",
                role:        "Líder Dep. C",
                company:     lexGo._id,
                ejective:    null,
                departament: lexGoCompaniesC._id,
            });
            employee_c.save();
            // SubEmployees
            new Employee({
                username:    "Luis Sánchez",
                role:        "Empleado Dep. C",
                company:     lexGo._id,
                ejective:    employee_c._id,
                departament: lexGoCompaniesC._id
            }).save();
            new Employee({
                username:    "Carmen Ramírez",
                role:        "Empleado Dep. C",
                company:     lexGo._id,
                ejective:    employee_c._id,
                departament: lexGoCompaniesC._id
            }).save();
            // Departamento C <--
        }, 3000);

        // List Data Content
        Company.find().exec().then(response => {
            response.map(company => {
                // Departamentos
                Departament.find({ company: new mongoose.Types.ObjectId(company._id) }).exec().then(departaments => {
                    departaments.map(departament => {
                        console.log(departament);
                        Employee.find({ departament: new mongoose.Types.ObjectId(departament._id), ejective: null }).exec().then(employees => { // Only List Ejective
                            console.log("# Ejecutive");
                            employees.map(ejective => {
                                Employee.find({ departament: new mongoose.Types.ObjectId(departament._id), ejective: new mongoose.Types.ObjectId(ejective._id) }).exec().then(employees => {
                                    console.log("# Empleados heredados de: " + ejective.username);
                                    console.log(ejective._id);
                                    console.log(employees);
                                });
                            });
                        });
                    });
                });
            });
        });
    });