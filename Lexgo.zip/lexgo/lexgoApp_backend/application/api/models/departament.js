const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const Departament = new mongoose.Schema({
  departament_id: { type: mongoose.Schema.Types.ObjectId, required: true, unique: true  },
  departament_name: { type: String, required: true },
  company:[
    { type: Schema.Types.ObjectId, ref: 'Company', required: true }
  ]
}, {
  timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' },
});


module.exports = mongoose.model('Departament', Departament);
