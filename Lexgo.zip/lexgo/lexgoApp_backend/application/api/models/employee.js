const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const EmployeSchema = new mongoose.Schema({
    username: { type: String, require: true },
    role: { type: String, require: true },
    company: { type: Schema.Types.ObjectId, ref: 'Company', required: true, default: null },
    departament: { type: Schema.Types.ObjectId, ref: 'Departament', required: true, default: null },
    ejective: { type: Schema.Types.ObjectId, ref: 'Employee', default: null }
}, {
  timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' },
});


module.exports = mongoose.model('Employe', EmployeSchema);