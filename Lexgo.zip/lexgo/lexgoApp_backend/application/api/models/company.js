const mongoose = require('mongoose');

const CompanySchema = new mongoose.Schema({
  company_id: { type: mongoose.Schema.Types.ObjectId, required: true, unique: true  },
  company_name: { type: String, required: true }
}, {
  timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' },
});


module.exports = mongoose.model('Company', CompanySchema);
