
const mongoose = require('mongoose');
const Company = require('../models/company');
const Departament = require('../models/departament');
const Employee = require('../models/employee');

const Structure = async (req, res) => {
    var companies = mongoose.connect('mongodb://127.0.0.1:27017/')
    .catch(err => {
        console.log(err.stack);
        process.exit(1);    
    })
    .then(async () => {
        // Solo la primera
        let companies = await Company.find().exec().then(response => {
            // Se buscan departamentos relacionados
            return Departament.find({ company: new mongoose.Types.ObjectId(response[0]._id) }).exec().then(departament => {
                return departament;
            });
        });

        return companies;
    });

    // Company
    let company = await Company.findOne().exec().then(r => r);

    // Resolve Response
    let departaments = await companies;

    let ejectives = await Employee.find({ ejective: null }).then(ejective => {
        return ejective;
    });
    let employees = await Employee.find({ ejective: { $ne: null }}).then(employee => {
        return employee;
    });

    let result = {
        company:      company,
        departaments: departaments,
        ejectives:    ejectives,
        employees:    employees
    };

    return res.json(result);
}

module.exports = Structure;