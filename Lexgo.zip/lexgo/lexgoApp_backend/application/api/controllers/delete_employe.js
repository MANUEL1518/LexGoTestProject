
const mongoose = require('mongoose');
const Company = require('../models/company');
const Departament = require('../models/departament');
const Employee = require('../models/employee');

const Structure = async (req, res) => {
    /**
     * req.params
     *  username
     *  departament
     *  ejecutive (null)
     */
    var response = mongoose.connect('mongodb://127.0.0.1:27017/')
    .catch(err => {
        console.log(err.stack);
        process.exit(1);    
    })
    .then(async () => {
        // Todos los que deriben de este mismo se quedan en el mismo departamento pero sin este lider
        if(req.params.employee_id !== '' && req.params.employee_id !== null) {
            console.log("# Update [Childrens]:", req.params.employee_id);
            let update_all = await Employee.updateMany({ ejective: req.params.employee_id }, {
                ejective: null
            });
            await update_all;
        }
        // Update Employee
        let employee = Employee.findByIdAndDelete(req.params.employee_id);

        return await employee;
    });

    // Resolve Response
    return res.json(req.params);
}

module.exports = Structure;