
const mongoose = require('mongoose');
const Company = require('../models/company');

const Structure = async (req, res) => {
    var companies = mongoose.connect('mongodb://127.0.0.1:27017/')
    .catch(err => {
        console.log(err.stack);
        process.exit(1);    
    })
    .then(async () => {
        let companies = await Company.find().exec().then(response => {
            return response;
        });

        return companies;
    });

    // Resolve Response
    return res.json(await companies);
}

module.exports = Structure;