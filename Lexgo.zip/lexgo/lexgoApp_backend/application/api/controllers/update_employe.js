
const mongoose = require('mongoose');
const Company = require('../models/company');
const Departament = require('../models/departament');
const Employee = require('../models/employee');

const Structure = async (req, res) => {
    /**
     * req.params
     *  username
     *  departament
     *  ejecutive (null)
     */
    var companies = mongoose.connect('mongodb://127.0.0.1:27017/')
    .catch(err => {
        console.log(err.stack);
        process.exit(1);    
    })
    .then(async () => {
        let to_update = {};
        if("username" in req.body && "role" in req.body) {
            to_update.username = req.body.username;
            to_update.role = req.body.role;
        }
        if("departament" in req.body && "ejective" in req.body) {
            let ejective_id = (req.body.ejective == "" || req.body.ejective == null)? null : req.body.ejective;

            to_update.departament = req.body.departament;
            to_update.ejective = ejective_id;

            // Todos los que deriben de este mismo se quedan en el mismo departamento pero sin este lider
            if(req.params.employee_id !== '' && req.params.employee_id !== null) { // 
                console.log("# Update", req.params.employee_id);
                /**
                 * Mientras que no cambie de Departamento no se le cambian la relación con su ejecutivo
                 */
                let update_all = await Employee.updateMany({ ejective: req.params.employee_id, departament: { $ne: req.body.departament } }, {
                    ejective: null
                });
                await update_all;
            }
        }
        // Update Employee
        let employee = Employee.findByIdAndUpdate(req.params.employee_id, to_update);
        
        return await employee;
    });

    // Resolve Response
    return res.json(req.params);
}

module.exports = Structure;