
const mongoose = require('mongoose');
const Company = require('../models/company');
const Departament = require('../models/departament');
const Employee = require('../models/employee');

const Structure = async (req, res) => {
    /**
     * req.params
     *  username
     *  departament
     *  ejecutive (null)
     */
    var companies = mongoose.connect('mongodb://127.0.0.1:27017/')
    .catch(err => {
        console.log(err.stack);
        process.exit(1);    
    })
    .then(async () => {
        // Create Employe
        let new_employee = new Employee({
            username:    req.body.username,
            role:        req.body.role,
            companie:    req.body.companie,
            departament: req.body.departament,
            ejective:    (req.body.ejective !== "" && req.body.ejective !== null)? req.body.ejective : null,
            company:     req.body.company._id
        });
        new_employee.save();

        return Employee.findById(new_employee._id).exec().then(new_emp => new_emp);
    });

    // Resolve Response
    return res.json(req.body);
}

module.exports = Structure;