
const mongoose = require('mongoose');
const Company = require('../models/company');
const Departament = require('../models/departament');

const Structure = async (req, res) => {
    var companies = mongoose.connect('mongodb://127.0.0.1:27017/')
    .catch(err => {
        console.log(err.stack);
        process.exit(1);    
    })
    .then(async () => {
        let companies = await Company.find({ _id: req.params["company_id"] }).exec().then(response => {
            if(response.length > 0) {
                // Se buscan departamentos relacionados
                let departaments = Departament.find({ company: new mongoose.Types.ObjectId(response[0].company_id) }).exec().then(departaments => {
                    return departaments;
                });

                return departaments;
            } else {
                return [];
            }
            
        });

        return companies;
    });

    // Resolve Response
    return res.json(await companies);
}

module.exports = Structure;