const express = require('express');
const mongoose = require('mongoose');

const company_structure = require('./application/api/controllers/company_structure');
const companies = require('./application/api/controllers/companies');
const all_structure = require('./application/api/controllers/all_structure');

const delete_employe = require('./application/api/controllers/delete_employe');
const update_employe = require('./application/api/controllers/update_employe');
const create_employee = require('./application/api/controllers/create_employee');

var cors = require('cors');

const app = express();

app.use(cors());
app.use(express.json());

app.listen(3000, () => {
    console.log(`Server Started at ${3000} | LexGo!!`)
});

app.get('/', (req, res) => {
    return res.json({
        admin: "LexGo!! To the API Resp"
    });
});

// List the structure
// app.get('/company_structure/:company_id', company_structure);
// app.get('/companies', companies);

app.get('/business_structure', all_structure)
app.delete('/employee/:employee_id', delete_employe)
app.put('/employee/:employee_id', update_employe)
app.post('/employee', create_employee)